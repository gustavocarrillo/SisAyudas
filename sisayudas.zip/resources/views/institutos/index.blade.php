<h1>Vista de Institutos</h1>
<br>
<p>@include('flash::message')</p>
<a href="{{ route('salir') }}">Salir</a>